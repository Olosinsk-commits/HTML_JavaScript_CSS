//Olga Osinskaya
//Assignment#2

/* Full program testing
1. I entered "o". I expected the screen to print out error message "Full Name must be greater than 2 characters.
The result was an error message "Full Name must be greater than 2 characters" Result confirmed.
2. I entered "olga". No error  message was printed. Result confirmed.
3. I entered "10" in the second field.  No error message was printed. Result confirmed.
4. I entered "11.0" in the secod field. I expected the screen to print out error message "Integer 1: must be an integer between 1 and 100".
The result was an error message "Integer 1: must be an integer between 1 and 100". Result confirmed.
5. I tested 3rd field for values less than 50 and more than 150, also for decimical values. And got correct error message.
Also, I tested 3rd field for correct values. They were accepted.
6. I tested 4th field on error for positive numbers. And that this field accepts negative decimical values.
7. I entered and tested 5th and 6th fields for not numbers values.
8. I entered 2-6 fields for non-numbers values and got correct error message.
9. I entered decimical value and tested that sum value printed in with float point.
*/
/* validateForm function testing
1. call function with logging.  Enter value to 1st field. Value assigned to var name.
2. call function with logging.  Enter value to 2st field. Value assigned to var integerO.
3. call function with logging. Enter value to 6th field. Value assigned to var integerFive.
*/


/**
 * The function validateForm takes values from following fields:
 * fullName, integerOne, integerTwo, integerThree, integerFour,integerFive, validates them,
 * stores in next variables: name,integerO,integerTw,integerTh
 * integerFo,integerFi, and display message.
 * @author: Olga Osinskaya
 * @return false if entered values incorrect and true if all entered values were correct
 * @param - none.
 */

function validateForm() {
  var name = document.forms["myForm"]["fullName"].value;
  var integerO = document.forms["myForm"]["integerOne"].value;
  var integerTw = document.forms["myForm"]["integerTwo"].value;
  var integerTh = document.forms["myForm"]["integerThree"].value;
  var integerFo = document.forms["myForm"]["integerFour"].value;
  var integerFi = document.forms["myForm"]["integerFive"].value;

//create array of our numbers
var arrayNumbers=[integerO, integerTw, integerTh, integerFo, integerFi];
//remove whitespases
for (var i=0; i<arrayNumbers.length; i++)
{
  arrayNumbers[i]=arrayNumbers[i].trim();
}

//check for name restrictions
if (name.length<=2 || !isNaN())
{
  document.getElementById("incorrectName").innerHTML ="Full Name must be greater than 2 characters";
  return false;
}
//clean error message
document.getElementById("incorrectName").innerHTML ="";
//check for integer1 restrictions
if (isNaN(integerO) || integerO < 1 || integerO > 100||integerO==""||(integerO%1!=0))
{
  document.getElementById("incorrectOne").innerHTML ="Integer 1: must be an integer between 1 and 100";
  return false;
}
//clean error message
document.getElementById("incorrectOne").innerHTML ="";
//check for integer2 restrictions
if (isNaN(integerTw)|| integerTw<50 || integerTw > 150 || integerTw==""||(integerTw%1!=0))
{
  document.getElementById("incorrectTwo").innerHTML ="Integer 2: must be an integer between 50 and 150";
  return false;
}
//clean error message
document.getElementById("incorrectTwo").innerHTML ="";
//check for number3 restrictions
if (isNaN(integerTh)|| integerTh>0 || integerTh=="")
{
  document.getElementById("incorrectThree").innerHTML ="Number 3: must be negative and allows for decimals";
  return false;
}
//clean error message
document.getElementById("incorrectThree").innerHTML ="";
//check for number4 restrictions
if (isNaN(integerFo)|| integerFo=="")
{
  document.getElementById("incorrectFour").innerHTML ="Number 4: any number, positive or negative";
  return false;
}
//clean error message
document.getElementById("incorrectFour").innerHTML ="";
//check for number5 restrictions
if (isNaN(integerFi)|| integerFi=="")
{
  document.getElementById("incorrectFive").innerHTML ="Number 5: any number, positive or negative";
  return false;
}
//clean error message
document.getElementById("incorrectFive").innerHTML ="";
//search for max and min value
var sum=0;//Keep the sum of all of the numbers
var max=0;//Keep the greatest number entered by user
var min=0;//Keep the smallest number entered by user
for (var i=0; i<arrayNumbers.length; i++)
{
//parse array values to float numbers
arrayNumbers[i]=parseFloat(arrayNumbers[i]);
//find sum all numbers in the array
sum+=arrayNumbers[i];
//find max and min values
if(arrayNumbers[i]>max)
{
  max=arrayNumbers[i];
}
if(arrayNumbers[i]<min)
{
  min=arrayNumbers[i];
}
}
//print user friendly responds to HTML page
document.getElementById("Conclusion").innerHTML ="Hello, " + name +". You entered: "+integerO+", "+integerTw+", "+integerTh+", "+integerFo+", "+integerFi;
document.getElementById("ConclusionContinue").innerHTML ="The largest number entered was "+max+".  The smallest number you entered was "+min+".  And the sum of all of the numbers was "+sum;

return true;
}
