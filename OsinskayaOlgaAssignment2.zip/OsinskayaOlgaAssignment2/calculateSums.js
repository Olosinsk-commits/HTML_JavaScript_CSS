//Olga Osinskaya
//Assignment#2

/* This program consists one calculateSums function and result display.

"Calculate Sums" program/function. Full testing.
1. I call function calculateSums with array of numbers [-7,-1,0,-1,2,-3]. This function returns false. I counted sum of Positive Numbers: 0+2=2
and absolute value of Negative Numbers: 7+1+1+3=12. 2>12 is false- return statement  correct. Result confirmed and displayed on HTML page.
2. I call function calculateSums with array of numbers [-1,2,-3,6]. This function returns true. I counted sum of Positive Numbers: 2+6=8
and absolute value of Negative Numbers: 1+3=4. 8>4 is true- return statement correct. Result confirmed and displayed on HTML page.
3. I call function calculateSums with array of numbers [-1,2]. This function returns true. I counted sum of Positive Numbers: 2=2
and absolute value of Negative Numbers: 1=1. 2>1 is true- return statement  correct. Result confirmed and displayed on HTML page.
4. I call function calculateSums with array of numbers [-1,2,8]. This function returns true. I counted sum of Positive Numbers: 2+8=10
and absolute value of Negative Numbers: 1=1. 10>1 is true- return statement correct. Result confirmed and displayed on HTML page.
*/

/**
 * The callAllSum function invokes calculateSums function with array of numbers.
 * @author: Olga Osinskaya
 * @param - none
 * @return {string} return statements of all test cases that you would like to try.
 */

function callAllSum()
{
  //test cases for console testing 
  //calculateSums([-1,2,-3,6]);
  //calculateSums([-1,2]);
  //calculateSums([-1,2,8]);
  //calculateSums([-7,-1,0,-1,2,-3]);
  var res="";
  res=res+calculateSums([-7,-1,0,-1,2,-3])+"<br><br>";
  res=res+calculateSums([-1,2,-3,6])+"<br><br>";
  res=res+calculateSums([-1,2])+"<br><br>";
  res=res+calculateSums([-1,2,8])+"<br><br>";
  document.getElementById("demo").innerHTML = res;
}

 /**
  * The calculateSums function accepts an array of numbers, and returns true if the sum
  * of all the positive numbers is greater than the sum of the absolute value of all the negative numbers.
  * @author: Olga Osinskaya
  * @param  array of numbers
  * @return {string} that includes true/false if the sum of all the positive numbers is greater than the sum of the
  absolute value of all the negative numbers. Also displays array of numbers and both sums
  */


function calculateSums(numbers)
{
  var sumPositiveNumbers=0;//sumPositiveNumbers variable stores sum of all Positive numbers
  var sumAbsoluteNumbers=0;//sumAbsoluteNumbers variable stores sum of the absolute value of all the negative numbers.
  //var arrayLength=numbers.length; //length of the passing array
  var PositiveNumbers="";
  var NegativeNumbers="";
  var counter=0;
  //while loop repeats a group of statements while counter<numbers.length
  while(counter<numbers.length)
  {
   if(numbers[counter]<0) // search all negative numbers
   {
   sumAbsoluteNumbers+=Math.abs(numbers[counter]);
   NegativeNumbers+=Math.abs(numbers[counter])+"+";
   }
   else // search all positive numbers
   {
     sumPositiveNumbers+=numbers[counter];
     PositiveNumbers+=numbers[counter]+"+";
   }
    counter++;
  }

  //(sumPositiveNumbers>sumAbsoluteNumbers) return true if the sum of all the positive numbers is greater than the sum of the absol ute value of all the negative numbers.
  return  "calculateSums(["+numbers+"]) is "
  +(sumPositiveNumbers>sumAbsoluteNumbers) +" ("+ sumPositiveNumbers+
  ">" + sumAbsoluteNumbers + ")" +"<br>Positive Numbers: "
  + PositiveNumbers.slice(0,PositiveNumbers.length-1)+"=" +sumPositiveNumbers+
  " Negative Numbers: " + NegativeNumbers.slice(0,NegativeNumbers.length-1)+"="+ sumAbsoluteNumbers;;
  //you can use lines below if you would like test solution in the console
  // console.log("calculateSums(["+numbers+"]): " +(sumPositiveNumbers>sumAbsoluteNumbers) +"("+ sumPositiveNumbers+
  // ">" + sumAbsoluteNumbers + ")");

  //or

  // console.log(sumPositiveNumbers>sumAbsoluteNumbers);
}
