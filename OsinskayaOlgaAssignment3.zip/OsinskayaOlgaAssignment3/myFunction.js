
/*Olga Osinskaya
Assignment#3*/

/*Validation logic
This program consists of functions Student, setGrade, fullName and display message.
1.  I created 1st object 'Jane', 'Doe', 'B' and printed result to html page. Result was correct as I expected 'Jane', 'Doe', 'B'.
2.  I created 2nd object 'Jane', 'Doe', 'C' and printed result to html page. Result was correct as I expected 'Jane', 'Doe', 'C'.
3.  I created 3rd object 'Olga', 'Osinskaya', 'A' and printed result to html page. Result was correct as I expected 'Olga', 'Osinskaya', 'A'.
4.  I call setGrade function for 1st object and set new grade A. New grade was assigned to current this object.
5.  I call fullName function on 3rd object and log this value to console.
6.  I call student1.setGrade(grade) method and passed Incorrect value as parameter. HTML page displayed correct error message
    "Incorrect value! Grades value must be in upper case A-F" and didn't change grade value
7.  I call student1.setGrade(grade) method and passed correct value as parameter. HTML page displayed correct  message
     and change was changed to new value
*/

/**
 * The Student constructor function creates object "Student's" type that can be used to create many objects of that type.
 * @author: Olga Osinskaya
 * @return {Student} The new Student object.
 * @param {String} -firstName, lastName, grade The desired parameters of the Student.
 */

  function Student(firstName, lastName, grade) {
    possibleGrades = ["A", "B", "C",  "D","F"];
    this.firstName = firstName; //Accessing to firstName properties
    this.lastName = lastName; //Accessing to lastName properties
     if (possibleGrades.indexOf(grade) > -1)
     this.grade = grade;//Accessing to grade properties
     else
     document.write("<p>" + "Incorrect value! Grades value must be in upper case A-F" + "</p>")


    /**
     * The setGrade() function assigns the value of grade to the person's grade property.
     * @author: Olga Osinskaya
     * @return {Student.grade}  new grade of the object that "owns" the JavaScript code grade value
     * @this {Student}
     * @param {String} -new grade of the object that "owns" the JavaScript code grade value
     */

    this.setGrade = function(grade) {

      if (possibleGrades.indexOf(grade) > -1)
      {
      this.grade = grade;
      document.write("<p>" + "Student: " + this.firstName + " " + this.lastName + ". Grade Changed to "+ this.grade + "</p>");
      }
        else
      document.write("<p>" + "Incorrect value! Grades value must be in upper case A-F" + "</p>");

      //this.grade = grade;
    }

    /**
     * The fullName() function returns the value of firstName+lastName.
     * @author: Olga Osinskaya
     * @return {this.firstName + " " + this.lastName} the fullname of the object that contains firstName+lastName
     * @this {Student}
     */
    this.fullName = function() {
      return this.firstName + " " + this.lastName;
    }
  }

  /**
   * The display() function function print all values to html page.
   * @author: Olga Osinskaya
   * @return {String} changes and table with current objects
   * @this {Student}
   */

  function display(){
  document.write("<p><b>" + "Changes log:"+ "</p></b>");
  //Creating a first Student object with properties: name Jane Doe and a grade of B.
  student1 = new Student('Jane', 'Doe', 'B');
  //Print the value
  document.write("<p>" +student1.fullName() + " has: " + student1.grade + "</p>");
  //Calling the setGrade method and changing the grade to an A.
  student1.setGrade('A');
  //Print the value
  document.write("<p>" +student1.fullName() + " now has: " + student1.grade + "</p>");

  //Creating a second Student object with properties: name John Doe with a grade of C.
  student2 = new Student('Jane', 'Doe', 'C');
  //Print the value
  document.write("<p>"  +student2.fullName() + " has: " + student2.grade + "</p>");
  //Creating a third Student object with properties: Olga Osinskaya and C grade
  student3 = new Student('Olga', 'Osinskaya', 'A');
  //Print the value
  document.write("<p>" + student3.fullName() + " has: " + student3.grade + "</p>");
  document.write("<p><b>" + "Final values in the Table format:"+ "</p></b>");

 //Display the students and their grades in a table on the page.
 //creating array of the student's(fullnames)
 var studentArrayName=[student1.fullName(),student2.fullName(),student3.fullName()];
 //creating array of the student's(grades)
 var studentArrayGrade=[student1.grade,student2.grade,student3.grade];
 //loop thru all values and output them in table
              for(var i=0; i < studentArrayName.length; i++)
               {
                //print results in the table
                 document.write("<tr>");
                 document.write("<td>"+(i+1)+"</td>"); //students number
                 document.write("<td>"+studentArrayName[i]+"</td>");//full name
                 document.write("<td>"+studentArrayGrade[i]+"</td>");//student's grade
                 document.write("</tr>");
               }

}
